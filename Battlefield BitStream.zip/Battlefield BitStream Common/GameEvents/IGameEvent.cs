﻿using Battlefield_BitStream_Common.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream_Common.GameEvents
{
    public interface IGameEvent
    {
        void Serialize(IBitStream stream);
        IGameEvent DeSerialize(IBitStream stream);
    }
}