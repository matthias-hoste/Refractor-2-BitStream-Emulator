﻿using Battlefield_BitStream_Common.GameEvents;
using Battlefield_BitStream_Common.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_2_BitStream.GameEvents
{
    public class ChallengeResponseEvent : IGameEvent
    {
        public void Serialize(IBitStream stream)
        {
            stream.WriteBits(2, 7);
            var bytes = new byte[73];
            stream.WriteBytes(bytes);
            stream.WriteBits(1768123489, 32);
            stream.WriteBits(353128704, 32);//Battlefield 2 latest net build
            stream.WriteBits(0, 1);
            stream.WriteBits(1059, 31);
        }
        public IGameEvent DeSerialize(IBitStream stream)
        {
            var s = stream.ReadBytes(73);
            var ss = stream.ReadBits(32);//1768123489
            var sss = stream.ReadBits(32);//Network Build Number
            var ssss = stream.ReadBits(1);
            var sssss = stream.ReadBits(31);
            var ssssss = Encoding.ASCII.GetString(s);
            return null;
        }
    }
}