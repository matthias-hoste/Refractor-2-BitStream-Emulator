﻿using Battlefield_2_BitStream.GameEvents;
using Battlefield_BitStream.Core.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream.Core.Managers
{
    public class GameEventManager
    {
        public virtual int ProcessReceivedPacket(BitStream stream)
        {
            uint val1 = stream.ReadBits(1);
            if (val1 != 1)
                return 1;
            uint numberOfEvents = stream.ReadBits(8);
            uint someVal2 = stream.ReadBits(5);
            uint eventId = 0;
            if (numberOfEvents > 0)
            {
                uint action2 = stream.ReadBits(1);
                if (action2 == 1)
                {

                }
                else
                {
                    int v3 = 127;//adjust value depending on game, 127 is for bf2 and bf2142
                    int v4 = 0;
                    do
                        ++v4;
                    while (v3 > (1 << v4) - 1);//if the event amount defined above is 127 then the result will be 7, meaning we read 7bits and those 7 bits are the event id
                    eventId = stream.ReadBits((uint)v4);
                    if(eventId == 3)
                    {
                        new ConnectionTypeEvent().DeSerialize(stream);
                    }
                    else if(eventId == 1)
                    {
                        var challenge = new ChallengeEvent().DeSerialize(stream);
                    }
                    else if(eventId == 2)
                    {
                        var challenge = new ChallengeResponseEvent().DeSerialize(stream);
                    }
                    else if(eventId == 11)
                    {
                        var remoteEvent = new PostRemoteEvent().DeSerialize(stream);
                    }
                    else
                    {

                    }
                    return 111;
                }
            }
            return 0;
        }
    }
}