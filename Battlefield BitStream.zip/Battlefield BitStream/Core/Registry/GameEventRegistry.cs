﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream.Core.Registry
{
    public class GameEventRegistry
    {
        public static GameEventRegistry Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new GameEventRegistry();
                return _instance;
            }
        }
        private static GameEventRegistry _instance { get; set; }
    }
}