﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using Battlefield_BitStream.Core.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Battlefield_BitStream.Core.Game;
using Battlefield_BitStream.Core.Structs;

namespace Battlefield_BitStream
{
    class Program
    {
        static Socket ClientSocket { get; set; }
        static byte[] Buffer = new byte[8192];
        static void Main(string[] args)
        {
            /*var gameClient = new GameClient();
            gameClient.Connect(353128704, "mods/bf2", new IPEndPoint(IPAddress.Parse("192.168.0.182"), 18567));
            Console.ReadLine();*/
            var gameServer = new GameServer();
            var strct = new NewPacketStruct();
            strct.Data = GetBytesFrom("6f200803000000cf001204840000000041010000043f1a003d484d3d2048616c6c2d4d616e6961204d6978205365727665720100e3003d484d3d2048616c6c2d4d616e6961204d697820536572766572202870726f043f7669646564206279206266326c2e6465297c2020202020202020202020202020202020202020202020202056656869636c653a204d6f202b20446f7c202020043f2020202020202020202020496e66616e747269653a204469202b204d69202b204672202b205361202b20536f7c7c20202020202020202020486f6d6570616700");
            strct.From = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1);
            gameServer._newPackets.Enqueue(strct);
            Console.ReadLine();
            ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            ClientSocket.Bind(new IPEndPoint(IPAddress.Any, 54102));
            EndPoint ep = new IPEndPoint(IPAddress.Any, 0);
            ClientSocket.BeginReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref ep, ReceiveCallback, null);
            var buff = new byte[0xffff];
            uint b = 0;
            b = BitStream.WriteBits(1, 4, buff, b);
            b = BitStream.WriteBits(1, 8, buff, b);
            b = BitStream.WriteBits(0x1002, 32, buff, b);
            b = BitStream.WriteBits(0012178483, 32, buff, b);
            b = BitStream.WriteBits(1, 1, buff, b);
            b = BitStream.WriteBits(0, 32, buff, b);
            b = BitStream.WriteString("", 32, buff, b);
            b = BitStream.WriteString("mods/bf2", 32, buff, b);
            var len = (((b) + 7) & ~7) >> 3;
            var sendArray = new byte[len];
            Array.Copy(buff, sendArray, len);
            ClientSocket.SendTo(sendArray, new IPEndPoint(IPAddress.Parse("192.168.0.182"), 18567));
            /*var stream = new BitStream(hex);
            readBasicHeader(stream);*/
            Console.ReadLine();
            return;
        }

        /*b = 0;
        b = write_bits(1,       4,  buff, b);
        b = write_bits(par1,    8,  buff, b);
        b = write_bits(par2,    32, buff, b);
        b = write_bits(ver,     32, buff, b);
        b = write_bits(1,       1,  buff, b);
        b = write_bits(0,       32, buff, b);
        b = write_bstr(pass,    32, buff, b);
        b = write_bstr(mod,     32, buff, b);
        len = PADDING(b) >> 3;*/

        private static void ReceiveCallback(IAsyncResult ar)
        {
            EndPoint ep = new IPEndPoint(IPAddress.Any, 0);
            int transferred = ClientSocket.EndReceiveFrom(ar, ref ep);
            var bytes = new byte[transferred];
            Array.Copy(Buffer, bytes, transferred);
            var stream = new BitStream(bytes);
            uint res = stream.ReadBits(4);
            uint someVal = stream.ReadBits(8);
            uint err = stream.ReadBits(32);
            EndPoint ep2 = new IPEndPoint(IPAddress.Any, 0);
            ClientSocket.BeginReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref ep2, ReceiveCallback, null);
        }

        public static byte[] GetBytesFrom(string hex)
        {
            var length = hex.Length / 2;
            var result = new byte[length];
            for (var i = 0; i < length; i++)
            {
                result[i] = byte.Parse(hex.Substring(i, 2), NumberStyles.HexNumber);
            }

            return result;
        }
        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }
    }
}
/*
signed int __cdecl dice::hfe::io::BitStream::readBits(dice::hfe::io::BitStream *this, void *outBuf, unsigned int Length)
{
  signed int result; // eax
  int Position; // edx
  _BYTE *Buffer; // edi
  char v6; // dl
  unsigned __int8 *v7; // ebx
  signed int v8; // esi
  unsigned __int8 v9; // al
  unsigned __int8 *i; // ebx
  unsigned __int8 v11; // dl
  char v12; // [esp+4h] [ebp-18h]
  char v13; // [esp+8h] [ebp-14h]

  result = 0;
  if ( outBuf && Length )
  {
    Position = *((_DWORD *)this + 4);//read position?
    if ( Length + Position <= *((_DWORD *)this + 6) )//total length
    {
      Buffer = outBuf;
      v6 = Position & 7;
      v12 = 8 - v6;
      v7 = (unsigned __int8 *)(*(_DWORD *)this + (*((_DWORD *)this + 4) >> 3));
      v8 = Length;
      v13 = v6;
      v9 = *v7;
      for ( i = v7 + 1; v8 > 7; v9 = v11 )
      {
        v11 = *i;
        v8 -= 8;
        ++i;
        *Buffer++ = ((signed int)v9 >> v13) | (v11 << v12);
      }
      if ( v8 > 0 )
        *Buffer = ((1 << v8) - 1) & ((*i << v12) | ((signed int)v9 >> v13));
      *((_DWORD *)this + 4) += Length;
      result = 1;
    }
    else
    {
      *((_BYTE *)this + 28) = 1;
      result = 0;
      *((_DWORD *)this + 8) = 2;
    }
  }
  return result;
}

//----- (08431280) --------------------------------------------------------
signed int __cdecl dice::hfe::io::BitStream::writeBits(dice::hfe::io::BitStream *this, const void *inBuf, unsigned int Length)
{
  unsigned int v3; // ecx
  unsigned int v4; // eax
  _BYTE *v6; // esi
  char v7; // bl
  unsigned int v8; // eax
  char v9; // cl
  _BYTE *v10; // eax
  _BYTE *v11; // esi
  unsigned __int8 v12; // al
  char *i; // ebx
  unsigned __int8 v14; // dl
  unsigned int v15; // eax
  bool v16; // cf
  bool v17; // zf
  char v18; // [esp+7h] [ebp-1Dh]
  char v19; // [esp+13h] [ebp-11h]
  _BYTE *v20; // [esp+14h] [ebp-10h]

  if ( !Length || *((_BYTE *)this + 28) )
    return 0;
  v3 = *((_DWORD *)this + 5);//write position?
  if ( Length + v3 > 8 * *((_DWORD *)this + 1) || (v4 = *((_DWORD *)this + 2)) != 0 && Length + v3 > v4 )
  {
    *((_BYTE *)this + 28) = 1;
    *((_DWORD *)this + 8) = 1;
    return 0;
  }
  v6 = (_BYTE *)((v3 >> 3) + *(_DWORD *)this);//unsure what this does
  v7 = Length + v3;
  v8 = Length + v3 - 1;
  v9 = v3 & 7;
  v10 = (_BYTE *)((v8 >> 3) + *(_DWORD *)this);//unsure what this does
  v20 = v10;
  v19 = *v10;
  v18 = ~(unsigned __int8)(255 >> ((8 - v7) & 7));
  *v6 = (*(unsigned __int8 *)inBuf << v9) | *v6 & (255 >> (8 - v9));
  v11 = v6 + 1;
  v12 = *(_BYTE *)inBuf;
  for ( i = (char *)inBuf + 1; v11 <= v20; v12 = v14 )
  {
    v14 = *i++;
    *v11++ = ((signed int)v12 >> (8 - v9)) | (v14 << v9);
  }
  *v20 = v18 & v19 | *v20 & ~v18;
  v15 = *((_DWORD *)this + 5) + Length;//write position?
  v16 = v15 < *((_DWORD *)this + 6);//total length
  v17 = v15 == *((_DWORD *)this + 6);//total length
  *((_DWORD *)this + 5) = v15;
  if ( !v16 && !v17 )
    *((_DWORD *)this + 6) = v15;//total length
  return 1;
}
 */
