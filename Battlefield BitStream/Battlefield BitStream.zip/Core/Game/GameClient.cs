﻿using Battlefield_BitStream.Core.IO;
using Battlefield_BitStream.Core.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream.Core.Game
{
    public class GameClient
    {
        private Socket _clientSocket { get; set; }
        private byte[] Buffer = new byte[8192];
        private uint slot { get; set; }
        public GameClient()
        {
            _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            _clientSocket.Bind(new IPEndPoint(IPAddress.Any, 0));
            try
            {
                EndPoint ep = new IPEndPoint(0x000000, 0);
                _clientSocket.BeginReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref ep, ClientReadCallback, null);
            }
            catch (Exception)
            {

            }
        }

        public void Connect(uint version, string mod, IPEndPoint ep)//65552
        {
            var buff = new byte[0xffff];
            uint b = 0;
            b = BitStream.WriteBasicHeader(1, 1, buff);
            b = BitStream.WriteBits(4098, 32, buff, b);
            b = BitStream.WriteBits(version, 32, buff, b);
            b = BitStream.WriteBits(1, 1, buff, b);//some sort of token, maybe to verify the ping request?
            b = BitStream.WriteBits(0, 32, buff, b);
            b = BitStream.WriteString("", 32, buff, b);
            b = BitStream.WriteString(mod, 32, buff, b);
            var len = (((b) + 7) & ~7) >> 3;
            var sendArray = new byte[len];
            Array.Copy(buff, sendArray, len);
            _clientSocket.SendTo(sendArray, ep);
        }

        private void ClientReadCallback(IAsyncResult ar)
        {
            IPEndPoint remote;
            int transferred = 0;
            try
            {
                EndPoint ep = new IPEndPoint(0x000000, 0);
                transferred = _clientSocket.EndReceiveFrom(ar, ref ep);
                if (transferred <= 0)
                    throw new Exception();
                remote = (IPEndPoint)ep;
            }
            catch (Exception)
            {
                return;
            }
            var bytes = new byte[transferred];
            Array.Copy(Buffer, bytes, transferred);
            var stream = new BitStream(bytes);
            uint type = 0;
            uint connectionId = 0;
            stream.ReadBasicHeader(ref type, ref connectionId);
            Console.WriteLine("[GameClient] handling packet received from " + remote.ToString() + ", connection id: " + connectionId);
            if (type == 0)
            {
                Console.WriteLine("[GameClient] skipping invalid packet");
                goto skip;
            }
            if (type == 1)
            {
                Console.WriteLine("[GameClient] received a connection request");
            }
            else if (type == 2)
            {
                Console.WriteLine("[GameClient] " + remote.ToString() + " received connect accept");
                slot = stream.ReadBits(8);
                Console.WriteLine("Server gave us connection id " + slot);
                SendConnectAcceptAck(remote);
                var data = Program.GetBytesFrom("6f100000000000040006000300");
                _clientSocket.SendTo(data, remote);
            }
            else if (type == 3)
            {
                Console.Write("[GameClient] " + remote.ToString() + " received connect denied");
                var err = stream.ReadBits(32);
                Console.WriteLine(", error: " + err);
            }
            else if (type == 4)
            {
                Console.WriteLine("[GameClient] " + remote.ToString() + " received connect ack");
            }
            else if (type == 5)
            {
                Console.WriteLine("[GameClient] " + remote.ToString() + " received disconnect");
            }
            else if (type == 7)
            {
                Console.WriteLine("[GameClient] " + remote.ToString() + " received ping request");
                uint type1 = 0;
                uint Type2 = 0;
                uint type3 = 0;
                stream.ReadExtendedHeader(ref type1, ref Type2, ref type3);
                uint i = stream.ReadBits(1);
                uint token = stream.ReadBits(32);
                SendPingReply(remote, token);
            }
            else if (type == 8)
            {//TODO: handle
                Console.WriteLine("[GameClient] " + remote.ToString() + " received ping response");
            }
            else if (type == 15)
            {
                Console.WriteLine("[GameClient] " + remote.ToString() + " received data packet");
                uint t1 = 0;
                uint t2 = 0;
                uint t3 = 0;
                stream.ReadExtendedHeader(ref t1, ref t2, ref t3);
                new PlayerActionManager().ProcessReceivedPacket(stream);
                new GameEventManager().ProcessReceivedPacket(stream);
                new GhostManager().ProcessReceivedPacket(stream);
            }
            else
            {

            }
            skip:
            try
            {
                EndPoint ep = new IPEndPoint(0x000000, 0);
                _clientSocket.BeginReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref ep, ClientReadCallback, null);
            }
            catch (Exception)
            {

            }
        }
        private void SendConnectAcceptAck(IPEndPoint ep)
        {
            try
            {
                var buff = new byte[0xffff];
                uint b = 0;
                b = BitStream.WriteBasicHeader(4, slot, buff);
                var len = (((b) + 7) & ~7) >> 3;
                var sendArray = new byte[len];
                Array.Copy(buff, sendArray, len);
                _clientSocket.SendTo(sendArray, ep);
            }
            catch (Exception)
            {

            }
        }
        private void SendPingReply(IPEndPoint ep, uint token)
        {
            try
            {
                var buff = new byte[0xffff];
                uint b = 0;
                b = BitStream.WriteBasicHeader(8, 0, buff);
                b = BitStream.WriteExtendedHeader(0, 0, 0, buff);
                b = BitStream.WriteBits(0, 1, buff, b);
                b = BitStream.WriteBits(token, 32, buff, b);
                b = BitStream.WriteBits(0, 32, buff, b);
                var len = (((b) + 7) & ~7) >> 3;
                var sendArray = new byte[len];
                Array.Copy(buff, sendArray, len);
                _clientSocket.SendTo(sendArray, ep);
            }
            catch (Exception)
            {

            }
        }
    }
}