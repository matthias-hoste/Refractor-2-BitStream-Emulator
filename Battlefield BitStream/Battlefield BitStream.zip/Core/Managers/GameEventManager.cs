﻿using Battlefield_BitStream.Core.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream.Core.Managers
{
    public class GameEventManager
    {
        public virtual int ProcessReceivedPacket(BitStream stream)
        {
            uint val1 = stream.ReadBits(1);
            if (val1 != 1)
                return 1;
            uint someVal = stream.ReadBits(8);
            uint someVal2 = stream.ReadBits(5);
            uint someVal3 = 0;
            if (someVal > 0)
            {
                uint action2 = stream.ReadBits(1);
                if (action2 == 1)
                {

                }
                else
                {
                    int v3 = 127;
                    int v4 = 0;
                    do
                        ++v4;
                    while (v3 > (1 << v4) - 1);
                    someVal3 = stream.ReadBits((uint)v4);
                    uint vvvv = stream.ReadBits(8);
                    var name = stream.ReadString(32);
                    return 111;
                }
            }
            return 0;
        }
    }
}