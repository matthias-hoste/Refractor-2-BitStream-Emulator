﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battlefield_BitStream.Core.IO
{
    public class BitStream
    {
        private byte[] _buffer { get; set; }
        public int Position { get; private set; }
        public int BitLength { get; private set; }
        public BitStream(byte[] data)
        {
            _buffer = data;
            Position = 0;
            BitLength = _buffer.Length * 8;
        }
        public void ReadBasicHeader(ref uint type, ref uint type2)
        {
            type = ReadBits(4);
            type2 = ReadBits(8);
        }
        public void ReadExtendedHeader(ref uint type1, ref uint dataId, ref uint type3)
        {
            type1 = ReadBits(6);
            dataId = ReadBits(6);
            type3 = ReadBits(32);
        }
        public string ReadString(uint len)
        {
            int i;
            string str = "";
            for (i = 0; i < len; i++)
            {
                str += (char)ReadBits(8);
            }
            return str;
        }
        public uint ReadBits(uint bits)
        {
            return ReadBits(bits, (uint)Position);
        }
        public uint ReadBits(uint bits, uint in_bits)
        {
            return ReadBits(bits, _buffer, in_bits);
        }
        public uint ReadBits(uint bits, byte[] i, uint in_bits)
        {
            uint seek_bits;
            uint rem;
            uint seek = 0;
            uint ret = 0;
            uint mask = 0xffffffff;
            Position += (int)bits;
            if (bits > 32)
            {
                return (0);
            }
            if (bits < 32)
            {
                mask = (uint)((1 << (int)bits) - 1);
            }
            for (; ; )
            {
                seek_bits = in_bits & 7;
                ret |= (uint)((i[in_bits >> 3] >> (int)seek_bits) & mask) << (int)seek;
                rem = (uint)(8 - seek_bits);
                if (rem >= bits)
                {
                    break;
                }
                bits -= rem;
                in_bits += rem;
                seek += rem;
                mask = (uint)((1 << (int)bits) - 1);
            }
            return (ret);
        }
        public static uint WriteBasicHeader(uint type, uint type2, byte[] @out)
        {
            uint i = 0;
            i = WriteBits(type, 4, @out, i);
            i = WriteBits(type2, 8, @out, i);
            return i;
        }
        public static uint WriteExtendedHeader(uint type, uint type2, uint type3, byte[] @out)
        {
            uint i = 0;
            i = WriteBits(type, 6, @out, i);
            i = WriteBits(type2, 6, @out, i);
            i = WriteBits(type3, 32, @out, i);
            return i;
        }
        public static uint WriteString(string data, uint len, byte[] buff, uint bitslen)
        {
            int i;

            for (i = 0; i < len; i++)
            {
                if (string.IsNullOrEmpty(data) || data.Length <= i)
                    break;
                bitslen = WriteBits(data[i], 8, buff, bitslen);
            }
            for (; i < len; i++)
            {
                bitslen = WriteBits(0, 8, buff, bitslen);
            }
            return (bitslen);
        }
        public static uint WriteBits(uint data, uint bits, byte[] @out, uint out_bits)
        {
            uint seek_bits;
            uint rem;
            uint mask;

            if (bits > 32)
            {
                return (out_bits);
            }
            if (bits < 32)
            {
                data &= (uint)(1 << (int)bits) - 1;
            }
            for (; ; )
            {
                seek_bits = out_bits & (uint)7;
                mask = (uint)((1 << (int)seek_bits) - 1);
                if ((bits + seek_bits) < 8)
                {
                    mask |= (uint)~(((1 << (int)bits) << (int)seek_bits) - 1);
                }
                @out[out_bits >> 3] &= (byte)mask; // zero
                @out[out_bits >> 3] |= (byte)(data << (int)seek_bits);
                rem = (8 - seek_bits);
                if (rem >= bits)
                {
                    break;
                }
                out_bits += rem;
                bits -= rem;
                data = (data >> (int)rem);
            }
            return (out_bits + bits);
        }
        public bool SkipBits(int bits)
        {
            if ((Position + bits) > BitLength)
                return false;
            Position += bits;
            return true;
        }
    }
}